import os
import sys

from PyQt5 import QtGui, QtWidgets, QtCore
from PyQt5.QtWidgets import QMessageBox
from Katana import NodegraphAPI

class MyMainWindow(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super(MyMainWindow, self).__init__(parent)

        self.setWindowTitle('My Tool')
        self.setMinimumSize(450,200)

        self.sp_widget = MainWidget()
        self.setCentralWidget(self.sp_widget)


class MainWidget(QtWidgets.QWidget):
    def __init__(self, parent = None):
        super(MainWidget, self).__init__(parent)
        self.build_ui()


    def build_ui(self):
        vbox = QtWidgets.QVBoxLayout(self)
        createswitchcamBtn = QtWidgets.QPushButton("Create Switch Cam")
        switchrotlightBtn = QtWidgets.QPushButton("Create Switch Rotation Light")
        disablesteadylightBtn = QtWidgets.QPushButton("Disable Steady Light")
        enablesteadylightBtn = QtWidgets.QPushButton("Enable Steady Light")

        vbox.addWidget(createswitchcamBtn)
        vbox.addWidget(switchrotlightBtn)
        vbox.addWidget(disablesteadylightBtn)
        vbox.addWidget(enablesteadylightBtn)

        createswitchcamBtn.clicked.connect(self.create_switch_cam)
        switchrotlightBtn.clicked.connect(self.create_switch_rotation_light)
        disablesteadylightBtn.clicked.connect(self.disable_steady_light)
        enablesteadylightBtn.clicked.connect(self.enable_steady_light)

    def create_switch_cam(self):
        msg = QMessageBox()
        groupOutputRenamer = NodegraphAPI.GetNode("OutputRenamer")

        if groupOutputRenamer is None:
            msg.warning(None, "Error Running", "OutputRenamer Not Avaible")
        else:
            groupOutputRenamerOutPort = groupOutputRenamer.getOutputPort("out")
            
            pruneBodyNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneBodyNode.setName('Prune_BodyGeo')
            NodegraphAPI.SetNodePosition(pruneBodyNode, (1300, -2250))
            pruneBodyNodeInPort = pruneBodyNode.getInputPort("A")
            pruneBodyNodeOutPort = pruneBodyNode.getOutputPort("out")

            pruneMouthOpenNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneMouthOpenNode.setName('Prune_MouthOpen')
            NodegraphAPI.SetNodePosition(pruneMouthOpenNode, (1000, -2250))
            pruneMouthOpenNodeInPort = pruneMouthOpenNode.getInputPort("A")
            pruneMouthOpenNodeOutPort = pruneMouthOpenNode.getOutputPort("out")
            
            groupOutputRenamerOutPort.connect(pruneBodyNodeInPort)
            
            pruneCamNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneCamNode.setName('Prune_Camera')
            NodegraphAPI.SetNodePosition(pruneCamNode, (1300, -2300))
            pruneCamNode.getParameter('cel').setValue("/root/world/cam/renderCam", 0)
            pruneCamNodeInPort = pruneCamNode.getInputPort("A")
            
            pruneBodyNodeOutPort.connect(pruneCamNodeInPort)
            
            camNode = NodegraphAPI.CreateNode('CameraCreate', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(camNode, (1500, -2300))
            camNode.setName('RenderCamera_Switch')
            camNode.getParameter("name").setValue("/root/world/cam/renderCam",0)
            camNode.getParameter("centerOfInterest").setValue(13.82215,0)
            camNode.getParameter("fov").setValue(10.29,0)
            camNode.getParameter("transform.translate.x").setValue(8.08842,0)
            camNode.getParameter("transform.translate.y").setValue(0.06661,0)
            camNode.getParameter("transform.translate.z").setValue(11.11527,0)
            camNode.getParameter("transform.rotate.x").setValue(4.0107,0)
            camNode.getParameter("transform.rotate.y").setValue(36.09634,0)
            camNode.getParameter("transform.rotate.z").setValue(-1.59e-15,0)
            
            mergeNode = NodegraphAPI.CreateNode('Merge', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(mergeNode, (1350, -2400))
            mergeNode.addInputPort('i0').connect(pruneCamNode.getOutputPort('out'))
            mergeNode.addInputPort('i1').connect(camNode.getOutputPort('out'))
            
            switchNode = NodegraphAPI.CreateNode('Switch', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(switchNode, (1200, -2470))
            OutputAttributeSetline = NodegraphAPI.GetNode("AttributeSet_lineMultiply")
            switchNode.addInputPort('i0').connect(OutputAttributeSetline.getOutputPort('out'))
            switchNode.addInputPort('i1').connect(mergeNode.getOutputPort('out'))

            switchNodeOutPort = switchNode.getOutputPort("output")

            timeoffsetNode = NodegraphAPI.GetNode("TimeOffset")
            timeoffsetNodeInPort = timeoffsetNode.getInputPort("input")

            switchNodeOutPort.connect(timeoffsetNodeInPort)

            msg.warning(None, "Success", "Just Copy AttributeSet_lineMultiply & Connect To Prune_BodyGeo")

    def create_switch_rotation_light(self):

        groupNode = NodegraphAPI.CreateNode('Group', NodegraphAPI.GetRootNode())
        groupNode.setName('Switch_Light')
        NodegraphAPI.SetNodePosition(groupNode, (-10, -1450))

        TransformLightOne = NodegraphAPI.CreateNode('Transform3D', NodegraphAPI.GetRootNode())
        TransformLightOne.setName('Default_Rotation')
        TransformLightOne.getParameter('path').setValue("/root/world/lgt/gaffer/keyLight_001", 0)
        TransformLightOne.getParameter('makeInteractive').setValue("Yes", 0)
        NodegraphAPI.SetNodePosition(TransformLightOne, (100, -10))
        TransformLightOne.setParent(groupNode)

        TransformLightTwo = NodegraphAPI.CreateNode('Transform3D', NodegraphAPI.GetRootNode())
        TransformLightTwo.setName('Change_Rotation')
        TransformLightTwo.getParameter('path').setValue("/root/world/lgt/gaffer/keyLight_001", 0)
        TransformLightTwo.getParameter('makeInteractive').setValue("Yes", 0)
        NodegraphAPI.SetNodePosition(TransformLightTwo, (300, -10))
        TransformLightTwo.setParent(groupNode)

        # Connect GafferThree Tp Transform
        GroupGafferThreeStackNode = NodegraphAPI.GetNode("GafferThree_Stack")
        GroupGafferThreeStackNodeOutPort = GroupGafferThreeStackNode.getOutputPort("out")
        TransformLightOneNodeInPort = TransformLightOne.getInputPort("in")
        TransformLightTwoNodeInPort = TransformLightTwo.getInputPort("in")
        GroupGafferThreeStackNodeOutPort.connect(TransformLightOneNodeInPort)
        GroupGafferThreeStackNodeOutPort.connect(TransformLightTwoNodeInPort)

        SwitchRot = NodegraphAPI.CreateNode('Switch', NodegraphAPI.GetRootNode())
        SwitchRot.setName('Switch_Rotation_Light')
        NodegraphAPI.SetNodePosition(SwitchRot, (200, -100))
        SwitchRot.setParent(groupNode)

        # Connect Transform to Switch
        SwitchRot.addInputPort('i0').connect(TransformLightOne.getOutputPort('out'))
        SwitchRot.addInputPort('i1').connect(TransformLightTwo.getOutputPort('out'))
        
        groupTurntableNode = NodegraphAPI.GetNode("Turntable")
        groupTurntableNodeInPort = groupTurntableNode.getInputPort("i0")

        SwitchRotNodeOutPort = SwitchRot.getOutputPort("output")
        SwitchRotNodeOutPort.connect(groupTurntableNodeInPort)

    def disable_steady_light(self):
        msg = QMessageBox()
        groupTurntableNode = NodegraphAPI.GetNode("Turntable")
        if groupTurntableNode is None:
            msg.warning(None, "Error Running", "Turntable Node Not Avaible")
        else:
            groupTurntableNode.getParameter('user.steady_light').setValue("false", 0)
            msg.about(self, "Info", "Steady Light Disable")

    def enable_steady_light(self):
        msg = QMessageBox()
        groupTurntableNode = NodegraphAPI.GetNode("Turntable")
        if groupTurntableNode is None:
            msg.warning(None, "Error Running", "Turntable Node Not Avaible")
        else:
            groupTurntableNode.getParameter('user.steady_light').setValue("true", 0)
            msg.about(self, "Info", "Steady Light Enable")

sp_window = MyMainWindow()
sp_window.show()