from Katana import NodegraphAPI

name_asset = "grendefaulta"
name1 = "dpr" + "_" + name_asset + "_" + "body" + "_" +"mat"
name2 = "dpr" + "_" + name_asset + "_" + "clothes" + "_" + "mat"
name3 = "dpr" + "_" + name_asset + "_" + "eyes" + "_" + "mat"
name4 = "dpr" + "_" + name_asset + "_" + "eyelashes" + "_" + "mat"
name5 = "dpr" + "_" + name_asset + "_" + "eyebrows" + "_" + "mat"
name6 = "dpr" + "_" + name_asset + "_" + "glints" + "_" + "mat"
name7 = "dpr" + "_" + name_asset + "_" + "hair" + "_" + "mat"
name8 = "dpr" + "_" + name_asset + "_" + "teeth" + "_" + "mat"
name9 = "dpr" + "_" + name_asset + "_" + "tongue" + "_" + "mat"
name10 = "dpr" + "_" + name_asset + "_" + "horns" + "_" + "mat"
name11 = "dpr" + "_" + name_asset + "_" + "toonlines" + "_" + "mat"

mat = "/root/materials/dpr_simpleToon_SHD" + "/"

##################################################################################
groupmatStackNode = NodegraphAPI.GetNode("Materials_Create_Stack")
groupmatStackNode1 = groupmatStackNode.buildChildNode()
groupmatStackNode2 = groupmatStackNode.buildChildNode()
groupmatStackNode3 = groupmatStackNode.buildChildNode()
groupmatStackNode4 = groupmatStackNode.buildChildNode()
groupmatStackNode5 = groupmatStackNode.buildChildNode()
groupmatStackNode6 = groupmatStackNode.buildChildNode()
groupmatStackNode7 = groupmatStackNode.buildChildNode()
groupmatStackNode8 = groupmatStackNode.buildChildNode()
groupmatStackNode9 = groupmatStackNode.buildChildNode()
groupmatStackNode10 = groupmatStackNode.buildChildNode()
groupmatStackNode11 = groupmatStackNode.buildChildNode()
NodegraphAPI.SetNodeEdited(groupmatStackNode, True, True)

groupmatAssignStackNode = NodegraphAPI.GetNode("Materials_Assign_Stack")
groupmatAssignStackNode1 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode2 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode3 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode4 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode5 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode6 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode7 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode8 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode9 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode10 = groupmatAssignStackNode.buildChildNode()
groupmatAssignStackNode11 = groupmatAssignStackNode.buildChildNode()
NodegraphAPI.SetNodeEdited(groupmatAssignStackNode, True, True)

##################################################################################
#Material Stack
##################################################################################
materialstackNode1 = NodegraphAPI.GetNode("Material5")
materialstackNode1.getParameter('name').setValue(name1, 0)
materialstackNode1.getParameter('action').setValue("create child material", 0)
materialstackNode1.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode2 = NodegraphAPI.GetNode("Material6")
materialstackNode2.getParameter('name').setValue(name2, 0)
materialstackNode2.getParameter('action').setValue("create child material", 0)
materialstackNode2.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode3 = NodegraphAPI.GetNode("Material15")
materialstackNode3.getParameter('name').setValue(name3, 0)
materialstackNode3.getParameter('action').setValue("create child material", 0)
materialstackNode3.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode4 = NodegraphAPI.GetNode("Material16")
materialstackNode4.getParameter('name').setValue(name4, 0)
materialstackNode4.getParameter('action').setValue("create child material", 0)
materialstackNode4.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode5 = NodegraphAPI.GetNode("Material17")
materialstackNode5.getParameter('name').setValue(name5, 0)
materialstackNode5.getParameter('action').setValue("create child material", 0)
materialstackNode5.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode6 = NodegraphAPI.GetNode("Material18")
materialstackNode6.getParameter('name').setValue(name6, 0)
materialstackNode6.getParameter('action').setValue("create child material", 0)
materialstackNode6.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode7 = NodegraphAPI.GetNode("Material19")
materialstackNode7.getParameter('name').setValue(name7, 0)
materialstackNode7.getParameter('action').setValue("create child material", 0)
materialstackNode7.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode8 = NodegraphAPI.GetNode("Material20")
materialstackNode8.getParameter('name').setValue(name8, 0)
materialstackNode8.getParameter('action').setValue("create child material", 0)
materialstackNode8.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode9 = NodegraphAPI.GetNode("Material21")
materialstackNode9.getParameter('name').setValue(name9, 0)
materialstackNode9.getParameter('action').setValue("create child material", 0)
materialstackNode9.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode10 = NodegraphAPI.GetNode("Material22")
materialstackNode10.getParameter('name').setValue(name10, 0)
materialstackNode10.getParameter('action').setValue("create child material", 0)
materialstackNode10.getParameter('inheritsFrom.location').setValue(mat, 0)

materialstackNode11 = NodegraphAPI.GetNode("Material23")
materialstackNode11.getParameter('name').setValue(name11, 0)
materialstackNode11.getParameter('action').setValue("create child material", 0)
materialstackNode11.getParameter('inheritsFrom.location').setValue(mat, 0)

##################################################################################
#Material ASsign
##################################################################################
materialassignNode1 = NodegraphAPI.GetNode("MaterialAssign6")
materialassignNode1.setName(name_one[:-1])
materialassignNode1.getParameter('args.materialAssign.value').setValue(mat + name1, 0)

materialassignNode2 = NodegraphAPI.GetNode("MaterialAssign7")
materialassignNode2.setName(name_two[:-1])
materialassignNode2.getParameter('args.materialAssign.value').setValue(mat + name2, 0)

materialassignNode3 = NodegraphAPI.GetNode("MaterialAssign8")
materialassignNode3.setName(name_three[:-1])
materialassignNode3.getParameter('args.materialAssign.value').setValue(mat + name3, 0)

materialassignNode4 = NodegraphAPI.GetNode("MaterialAssign9")
materialassignNode4.setName(name_four[:-1])
materialassignNode4.getParameter('args.materialAssign.value').setValue(mat + name4, 0)

materialassignNode5 = NodegraphAPI.GetNode("MaterialAssign10")
materialassignNode5.setName(name_five[:-1])
materialassignNode5.getParameter('args.materialAssign.value').setValue(mat + name5, 0)

materialassignNode6 = NodegraphAPI.GetNode("MaterialAssign11")
materialassignNode6.setName(name_six[:-1])
materialassignNode6.getParameter('args.materialAssign.value').setValue(mat + name6, 0)

materialassignNode7 = NodegraphAPI.GetNode("MaterialAssign12")
materialassignNode7.setName(name_seven[:-1])
materialassignNode7.getParameter('args.materialAssign.value').setValue(mat + name7, 0)

materialassignNode8 = NodegraphAPI.GetNode("MaterialAssign13")
materialassignNode8.setName(name_eight[:-1])
materialassignNode8.getParameter('args.materialAssign.value').setValue(mat + name8, 0)

materialassignNode9 = NodegraphAPI.GetNode("MaterialAssign14")
materialassignNode9.setName(name_nine[:-1])
materialassignNode9.getParameter('args.materialAssign.value').setValue(mat + name9, 0)

materialassignNode10 = NodegraphAPI.GetNode("MaterialAssign15")
materialassignNode10.setName(name_ten[:-1])
materialassignNode10.getParameter('args.materialAssign.value').setValue(mat + name10, 0)

materialassignNode11 = NodegraphAPI.GetNode("MaterialAssign16")
materialassignNode11.setName(name_eleven[:-1])
materialassignNode11.getParameter('args.materialAssign.value').setValue(mat + name11, 0)