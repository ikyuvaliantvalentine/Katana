# from PyQt5.QtWidgets import (QApplication, QComboBox, QDialog,
# QDialogButtonBox, QFormLayout, QGridLayout, QGroupBox, QHBoxLayout,
# QLabel, QLineEdit, QMenu, QMenuBar, QPushButton, QSpinBox, QTextEdit,
# QVBoxLayout, QMessageBox)
from PyQt5.QtWidgets import *
import sys

class CustomKatanaTools(QDialog):
    def __init__(self):
        super(CustomKatanaTools, self).__init__()

        self.setWindowTitle("Custom Tools")
        self.setMinimumSize(300,200)
        
        createswitchcamBtn = QPushButton("Create Switch Cam")
        switchrotlightBtn = QPushButton("Create Switch Rotation Light")
        checkboxsteadylight = QCheckBox("Steady Light")
        checkboxcameramode = QCheckBox("Camera Mode")

        mainLayout = QVBoxLayout()
        mainLayout.addWidget(createswitchcamBtn)
        mainLayout.addWidget(switchrotlightBtn)
        mainLayout.addWidget(checkboxsteadylight)
        mainLayout.addWidget(checkboxcameramode)
        self.setLayout(mainLayout)

        createswitchcamBtn.clicked.connect(self.create_switch_cam)
        switchrotlightBtn.clicked.connect(self.create_switch_rotation_light)
        checkboxsteadylight.stateChanged.connect(self.toggle_steady_light)
        checkboxcameramode.stateChanged.connect(self.toggle_camera)

        # Disable CheckBox UI
        groupTurntableNode = NodegraphAPI.GetNode("Turntable")
        if groupTurntableNode is None:
            checkboxsteadylight.setEnabled(False)
        else:
            checkboxsteadylight.setEnabled(True)

        groupCameraNode = NodegraphAPI.GetNode("Cameras")
        if groupCameraNode is None:
            checkboxcameramode.setEnabled(False)
        else:
            checkboxcameramode.setEnabled(True)

    def create_switch_cam(self):
        msg = QMessageBox()
        groupOutputRenamer = NodegraphAPI.GetNode("OutputRenamer")

        if groupOutputRenamer is None:
            msg.warning(None, "Error Running", "OutputRenamer Not Avaible")
        else:
            groupOutputRenamerOutPort = groupOutputRenamer.getOutputPort("out")
            
            pruneBodyNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneBodyNode.setName('Prune_BodyGeo')
            NodegraphAPI.SetNodePosition(pruneBodyNode, (1300, -2250))
            pruneBodyNodeInPort = pruneBodyNode.getInputPort("A")
            pruneBodyNodeOutPort = pruneBodyNode.getOutputPort("out")

            pruneMouthOpenNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneMouthOpenNode.setName('Prune_MouthOpen')
            NodegraphAPI.SetNodePosition(pruneMouthOpenNode, (1000, -2250))
            pruneMouthOpenNodeInPort = pruneMouthOpenNode.getInputPort("A")
            pruneMouthOpenNodeOutPort = pruneMouthOpenNode.getOutputPort("out")
            
            groupOutputRenamerOutPort.connect(pruneBodyNodeInPort)
            
            pruneCamNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneCamNode.setName('Prune_Camera')
            NodegraphAPI.SetNodePosition(pruneCamNode, (1300, -2300))
            pruneCamNode.getParameter('cel').setValue("/root/world/cam/renderCam", 0)
            pruneCamNodeInPort = pruneCamNode.getInputPort("A")
            
            pruneBodyNodeOutPort.connect(pruneCamNodeInPort)
            
            camNode = NodegraphAPI.CreateNode('CameraCreate', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(camNode, (1500, -2300))
            camNode.setName('RenderCamera_Switch')
            camNode.getParameter("name").setValue("/root/world/cam/renderCam",0)
            camNode.getParameter("centerOfInterest").setValue(13.82215,0)
            camNode.getParameter("fov").setValue(10.29,0)
            camNode.getParameter("transform.translate.x").setValue(8.08842,0)
            camNode.getParameter("transform.translate.y").setValue(0.06661,0)
            camNode.getParameter("transform.translate.z").setValue(11.11527,0)
            camNode.getParameter("transform.rotate.x").setValue(4.0107,0)
            camNode.getParameter("transform.rotate.y").setValue(36.09634,0)
            camNode.getParameter("transform.rotate.z").setValue(-1.59e-15,0)
            
            mergeNode = NodegraphAPI.CreateNode('Merge', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(mergeNode, (1350, -2400))
            mergeNode.addInputPort('i0').connect(pruneCamNode.getOutputPort('out'))
            mergeNode.addInputPort('i1').connect(camNode.getOutputPort('out'))
            
            switchNode = NodegraphAPI.CreateNode('Switch', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(switchNode, (1200, -2470))
            OutputAttributeSetline = NodegraphAPI.GetNode("AttributeSet_lineMultiply")
            switchNode.addInputPort('i0').connect(OutputAttributeSetline.getOutputPort('out'))
            switchNode.addInputPort('i1').connect(mergeNode.getOutputPort('out'))

            switchNodeOutPort = switchNode.getOutputPort("output")

            timeoffsetNode = NodegraphAPI.GetNode("TimeOffset")
            timeoffsetNodeInPort = timeoffsetNode.getInputPort("input")

            switchNodeOutPort.connect(timeoffsetNodeInPort)

            msg.about(self, "Success", "Just Copy AttributeSet_lineMultiply & Connect To Prune_BodyGeo")

    def create_switch_rotation_light(self):
        msg = QMessageBox()
        GroupGafferThreeStackNode = NodegraphAPI.GetNode("GafferThree_Stack")
        if GroupGafferThreeStackNode is None:
            msg.warning(None, "Error Running", "GafferThree_Stack Not Avaible")
        else:
            groupNode = NodegraphAPI.CreateNode('Group', NodegraphAPI.GetRootNode())
            groupNode.setName('Switch_Light')
            NodegraphAPI.SetNodePosition(groupNode, (-10, -1450))

            TransformLightOne = NodegraphAPI.CreateNode('Transform3D', NodegraphAPI.GetRootNode())
            TransformLightOne.setName('Default_Rotation')
            TransformLightOne.getParameter('path').setValue("/root/world/lgt/gaffer/keyLight_001", 0)
            TransformLightOne.getParameter('makeInteractive').setValue("Yes", 0)
            NodegraphAPI.SetNodePosition(TransformLightOne, (100, -10))
            TransformLightOne.setParent(groupNode)

            TransformLightTwo = NodegraphAPI.CreateNode('Transform3D', NodegraphAPI.GetRootNode())
            TransformLightTwo.setName('Change_Rotation')
            TransformLightTwo.getParameter('path').setValue("/root/world/lgt/gaffer/keyLight_001", 0)
            TransformLightTwo.getParameter('makeInteractive').setValue("Yes", 0)
            NodegraphAPI.SetNodePosition(TransformLightTwo, (300, -10))
            TransformLightTwo.setParent(groupNode)

            # Connect GafferThree Tp Transform
            GroupGafferThreeStackNode = NodegraphAPI.GetNode("GafferThree_Stack")
            GroupGafferThreeStackNodeOutPort = GroupGafferThreeStackNode.getOutputPort("out")
            TransformLightOneNodeInPort = TransformLightOne.getInputPort("in")
            TransformLightTwoNodeInPort = TransformLightTwo.getInputPort("in")
            GroupGafferThreeStackNodeOutPort.connect(TransformLightOneNodeInPort)
            GroupGafferThreeStackNodeOutPort.connect(TransformLightTwoNodeInPort)

            SwitchRot = NodegraphAPI.CreateNode('Switch', NodegraphAPI.GetRootNode())
            SwitchRot.setName('Switch_Rotation_Light')
            NodegraphAPI.SetNodePosition(SwitchRot, (200, -100))
            SwitchRot.setParent(groupNode)

            # Connect Transform to Switch
            SwitchRot.addInputPort('i0').connect(TransformLightOne.getOutputPort('out'))
            SwitchRot.addInputPort('i1').connect(TransformLightTwo.getOutputPort('out'))
            
            groupTurntableNode = NodegraphAPI.GetNode("Turntable")
            groupTurntableNodeInPort = groupTurntableNode.getInputPort("i0")

            SwitchRotNodeOutPort = SwitchRot.getOutputPort("output")
            SwitchRotNodeOutPort.connect(groupTurntableNodeInPort)

    def toggle_steady_light(self, state):
        msg = QMessageBox()
        groupTurntableNode = NodegraphAPI.GetNode("Turntable")
        if state == QtCore.Qt.Checked:
            groupTurntableNode.getParameter('user.steady_light').setValue("false", 0)
            msg.about(self, "Info", "Disable Steady Light")
        else:
            groupTurntableNode.getParameter('user.steady_light').setValue("true", 0)
            msg.about(self, "Info", "Enable Steady Light")

    def toggle_camera(self, state):
        msg = QMessageBox()
        groupCamerasNode = NodegraphAPI.GetNode("Cameras")
        if state == QtCore.Qt.Checked:
            groupCamerasNode.getParameter('user.camera').setValue("turntable", 0)
            msg.about(self, "Info", "Camera Turntable Mode")
        else:
            groupCamerasNode.getParameter('user.camera').setValue("free", 0)
            msg.about(self, "Info", "Camera Free Mode")
 
sp_window = CustomKatanaTools()
sp_window.show()