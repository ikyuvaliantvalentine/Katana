from PyQt5.QtWidgets import *
import sys

class App(QtWidgets.QMainWindow):
    def __init__(self):
        super(App, self).__init__()
        self.window = MainWindow(self)
        self.resize(500, 200)
        self.setCentralWidget(self.window)
        self.setWindowTitle("Custom Tools") # Window Title
        self.show()

class GeneralWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(GeneralWidget, self).__init__(parent)
        # Button
        createswitchcamBtn = QtWidgets.QPushButton("Create Switch Cam")
        switchrotlightBtn = QtWidgets.QPushButton("Create Switch Rotation Light")
        simswitchcamBtn = QtWidgets.QPushButton("Simple Switch Cam")
        test = QtWidgets.QPushButton("Save")
        test1 = QtWidgets.QPushButton("Save Increment")
        test2 = QtWidgets.QPushButton("Import")

        # Button Function
        createswitchcamBtn.clicked.connect(self.create_switch_cam)
        switchrotlightBtn.clicked.connect(self.create_switch_rotation_light)
        simswitchcamBtn.clicked.connect(self.create_simple_switch_cam)
        
        camLayout = QtWidgets.QHBoxLayout() # Crete horizontal Test UI
        camLayout.addWidget(test1)
        camLayout.addWidget(test)
        camLayout.addWidget(test2)

        # Final Layout
        verticalLayout = QtWidgets.QVBoxLayout(self)
        verticalLayout.addWidget(createswitchcamBtn)
        verticalLayout.addWidget(switchrotlightBtn)
        verticalLayout.addWidget(simswitchcamBtn)

        verticalLayout.addLayout(camLayout) # Add Camera Layout
        verticalLayout.addStretch()

        self.setLayout(verticalLayout)

    def create_switch_cam(self):
        msg = QMessageBox()
        groupOutputRenamer = NodegraphAPI.GetNode("OutputRenamer")

        if groupOutputRenamer is None:
            msg.warning(None, "Error Running", "OutputRenamer Not Avaible")
        else:
            groupOutputRenamerOutPort = groupOutputRenamer.getOutputPort("out")
            
            pruneBodyNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneBodyNode.setName('Prune_BodyGeo')
            NodegraphAPI.SetNodePosition(pruneBodyNode, (1300, -2250))
            pruneBodyNodeInPort = pruneBodyNode.getInputPort("A")
            pruneBodyNodeOutPort = pruneBodyNode.getOutputPort("out")

            pruneMouthOpenNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneMouthOpenNode.setName('Prune_MouthOpen')
            NodegraphAPI.SetNodePosition(pruneMouthOpenNode, (1000, -2250))
            pruneMouthOpenNodeInPort = pruneMouthOpenNode.getInputPort("A")
            pruneMouthOpenNodeOutPort = pruneMouthOpenNode.getOutputPort("out")
            
            groupOutputRenamerOutPort.connect(pruneBodyNodeInPort)
            
            pruneCamNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneCamNode.setName('Prune_Camera')
            NodegraphAPI.SetNodePosition(pruneCamNode, (1300, -2300))
            pruneCamNode.getParameter('cel').setValue("/root/world/cam/renderCam", 0)
            pruneCamNodeInPort = pruneCamNode.getInputPort("A")
            
            pruneBodyNodeOutPort.connect(pruneCamNodeInPort)
            
            camNode = NodegraphAPI.CreateNode('CameraCreate', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(camNode, (1500, -2300))
            camNode.setName('RenderCamera_Switch')
            camNode.getParameter("name").setValue("/root/world/cam/renderCam",0)
            camNode.getParameter("centerOfInterest").setValue(13.82215,0)
            camNode.getParameter("fov").setValue(10.29,0)
            camNode.getParameter("transform.translate.x").setValue(8.08842,0)
            camNode.getParameter("transform.translate.y").setValue(0.06661,0)
            camNode.getParameter("transform.translate.z").setValue(11.11527,0)
            camNode.getParameter("transform.rotate.x").setValue(4.0107,0)
            camNode.getParameter("transform.rotate.y").setValue(36.09634,0)
            camNode.getParameter("transform.rotate.z").setValue(-1.59e-15,0)
            
            mergeNode = NodegraphAPI.CreateNode('Merge', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(mergeNode, (1350, -2400))
            mergeNode.addInputPort('i0').connect(pruneCamNode.getOutputPort('out'))
            mergeNode.addInputPort('i1').connect(camNode.getOutputPort('out'))
            
            switchNode = NodegraphAPI.CreateNode('Switch', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(switchNode, (1200, -2470))
            OutputAttributeSetline = NodegraphAPI.GetNode("AttributeSet_lineMultiply")
            switchNode.addInputPort('i0').connect(OutputAttributeSetline.getOutputPort('out'))
            switchNode.addInputPort('i1').connect(mergeNode.getOutputPort('out'))

            switchNodeOutPort = switchNode.getOutputPort("output")

            timeoffsetNode = NodegraphAPI.GetNode("TimeOffset")
            timeoffsetNodeInPort = timeoffsetNode.getInputPort("input")

            switchNodeOutPort.connect(timeoffsetNodeInPort)

            msg.about(self, "Success", "Just Copy AttributeSet_lineMultiply & Connect To Prune_BodyGeo")

    def create_switch_rotation_light(self):
        GroupGafferThreeStackNode = NodegraphAPI.GetNode("GafferThree_Stack")
        if GroupGafferThreeStackNode is None:
            QMessageBox.warning(None, "Error Running", "GafferThree_Stack Not Avaible")
        else:
            groupNode = NodegraphAPI.CreateNode('Group', NodegraphAPI.GetRootNode())
            groupNode.setName('Switch_Light')
            NodegraphAPI.SetNodePosition(groupNode, (-5.153, -1450))

            TransformLightOne = NodegraphAPI.CreateNode('Transform3D', NodegraphAPI.GetRootNode())
            TransformLightOne.setName('Default_Rotation')
            TransformLightOne.getParameter('path').setValue("/root/world/lgt/gaffer/keyLight_001", 0)
            TransformLightOne.getParameter('makeInteractive').setValue("Yes", 0)
            NodegraphAPI.SetNodePosition(TransformLightOne, (100, -10))
            TransformLightOne.setParent(groupNode)

            TransformLightTwo = NodegraphAPI.CreateNode('Transform3D', NodegraphAPI.GetRootNode())
            TransformLightTwo.setName('Change_Rotation')
            TransformLightTwo.getParameter('path').setValue("/root/world/lgt/gaffer/keyLight_001", 0)
            TransformLightTwo.getParameter('makeInteractive').setValue("Yes", 0)
            NodegraphAPI.SetNodePosition(TransformLightTwo, (300, -10))
            TransformLightTwo.setParent(groupNode)

            # Connect GafferThree Tp Transform
            GroupGafferThreeStackNode = NodegraphAPI.GetNode("GafferThree_Stack")
            GroupGafferThreeStackNodeOutPort = GroupGafferThreeStackNode.getOutputPort("out")
            TransformLightOneNodeInPort = TransformLightOne.getInputPort("in")
            TransformLightTwoNodeInPort = TransformLightTwo.getInputPort("in")
            GroupGafferThreeStackNodeOutPort.connect(TransformLightOneNodeInPort)
            GroupGafferThreeStackNodeOutPort.connect(TransformLightTwoNodeInPort)

            SwitchRot = NodegraphAPI.CreateNode('Switch', NodegraphAPI.GetRootNode())
            SwitchRot.setName('Switch_Rotation_Light')
            NodegraphAPI.SetNodePosition(SwitchRot, (200, -100))
            SwitchRot.setParent(groupNode)

            # Connect Transform to Switch
            SwitchRot.addInputPort('i0').connect(TransformLightOne.getOutputPort('out'))
            SwitchRot.addInputPort('i1').connect(TransformLightTwo.getOutputPort('out'))
            
            groupTurntableNode = NodegraphAPI.GetNode("Turntable")
            groupTurntableNodeInPort = groupTurntableNode.getInputPort("i0")

            SwitchRotNodeOutPort = SwitchRot.getOutputPort("output")
            SwitchRotNodeOutPort.connect(groupTurntableNodeInPort)
            QMessageBox.about(self, "Success", "Success Create Switch Light Node")

    def create_simple_switch_cam(self):
        GroupCamerasNode = NodegraphAPI.GetNode("Cameras")
        if GroupCamerasNode is None:
            QMessageBox.warning(None, "Error Running", "Group Cameras Node Not Avaible")
        else:
            GroupSwitchCamNode = NodegraphAPI.CreateNode('Group', NodegraphAPI.GetRootNode())
            GroupSwitchCamNode.setName('Simple_Switch_Cam')
            NodegraphAPI.SetNodePosition(GroupSwitchCamNode, (-5.153, -2570))

            timeoffsetNode = NodegraphAPI.GetNode("TimeOffset")
            timeoffsetNodeOutPort = timeoffsetNode.getOutputPort("output")

            pruneCamNode = NodegraphAPI.CreateNode('Prune', NodegraphAPI.GetRootNode())
            pruneCamNode.setName('Prune_RenderCam')
            pruneCamNode.getParameter('cel').setValue("/root/world/cam/renderCam", 0)
            NodegraphAPI.SetNodePosition(pruneCamNode, (-62.5, 107.0))
            pruneCamNodeInPort = pruneCamNode.getInputPort("A")
            pruneCamNode.setParent(GroupSwitchCamNode)

            timeoffsetNodeOutPort.connect(pruneCamNodeInPort)

            newrencamNode = NodegraphAPI.CreateNode('CameraCreate', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(newrencamNode, (134.4, 107.0))
            newrencamNode.setName('New_RenderCamera')
            newrencamNode.getParameter("name").setValue("/root/world/cam/renderCam",0)
            newrencamNode.getParameter("fov").setValue(10.29,0)
            newrencamNode.setParent(GroupSwitchCamNode)

            mergeNode = NodegraphAPI.CreateNode('Merge', NodegraphAPI.GetRootNode())
            NodegraphAPI.SetNodePosition(mergeNode, (11.0, 6.0))
            mergeNode.setParent(GroupSwitchCamNode)

            # Connect Prune Render Cam & New Render Camera
            mergeNode.addInputPort('i0').connect(pruneCamNode.getOutputPort('out'))
            mergeNode.addInputPort('i1').connect(newrencamNode.getOutputPort('out'))
            
            switchNode = NodegraphAPI.CreateNode('Switch', NodegraphAPI.GetRootNode())
            switchNode.setName('Simple_Camera_Switch')
            NodegraphAPI.SetNodePosition(switchNode, (12.5, -91.5))
            switchNode.setParent(GroupSwitchCamNode)

            switchNode.addInputPort('i0').connect(timeoffsetNode.getOutputPort('output'))
            switchNode.addInputPort('i1').connect(mergeNode.getOutputPort('out'))

            RenderNode = NodegraphAPI.GetNode("Render")
            RenderNodeInPort = RenderNode.getInputPort("input")
            RenderNodeInPort.connect(switchNode.getOutputPort('output'))

            QMessageBox.about(self, "Success", "Success Create Switch Light Node")

class OptionsWidget(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(OptionsWidget, self).__init__(parent)
        # Enum List
        camdata = ['free', 'turntable']
        camera_switch = QtWidgets.QLabel("Camera Switch")
        camera_switch_options = QtWidgets.QComboBox(self)
        camera_switch_options.addItems(camdata)
        camLayout = QtWidgets.QHBoxLayout() # Create layout camera
        camLayout.addWidget(camera_switch)
        camLayout.addWidget(camera_switch_options)

        steadylightdata = ['true', 'false']
        steady_light_switch = QtWidgets.QLabel("Steady Light")
        steady_light_switch_options = QtWidgets.QComboBox(self)
        steady_light_switch_options.addItems(steadylightdata)
        steadylightLayout = QtWidgets.QHBoxLayout() # Create layout steady light
        steadylightLayout.addWidget(steady_light_switch)
        steadylightLayout.addWidget(steady_light_switch_options)

        # Enum Function
        camera_switch_options.activated[str].connect(self.CameraOptions)
        steady_light_switch_options.activated[str].connect(self.LightOptions)

        # Final Layout
        verticalLayout = QtWidgets.QVBoxLayout(self)
        verticalLayout.addLayout(camLayout) # Add Camera Layout
        verticalLayout.addLayout(steadylightLayout) # Add Steady Light Layout
        
        verticalLayout.addStretch()

        self.setLayout(verticalLayout)

    def CameraOptions(self, val):
        groupCamerasNode = NodegraphAPI.GetNode("Cameras")
        if val == "turntable":
            groupCamerasNode.getParameter('user.camera').setValue("turntable", 0)
            QMessageBox.about(self, "Info", "Camera Turntable Mode")
        elif val == "free":
            groupCamerasNode.getParameter('user.camera').setValue("free", 0)
            QMessageBox.about(self, "Info", "Camera Free Mode")

    def LightOptions(self, val):
        groupTurntableNode = NodegraphAPI.GetNode("Turntable")
        if val == "true":
            groupTurntableNode.getParameter('user.steady_light').setValue("true", 0)
            QMessageBox.about(self, "Info", "Enable Steady Light")
        elif val == "false":
            groupTurntableNode.getParameter('user.steady_light').setValue("false", 0)
            QMessageBox.about(self, "Info", "Disable Steady Light")

class MainWindow(QtWidgets.QWidget):        
    def __init__(self, parent):   
        super(MainWindow, self).__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        # Run this after settings
        # self.lang = getLang(config.get("Main", "language"))
        # Initialize tabs
        tab_holder = QtWidgets.QTabWidget()   # Create tab holder
        tab_1 = GeneralWidget()           # Tab one
        tab_2 = OptionsWidget()           # Tab two
        # Add tabs
        tab_holder.addTab(tab_1, "General") #self.lang["tab_1_title"]) # Add "tab1" to the tabs holder "tabs"
        tab_holder.addTab(tab_2, "Options") #self.lang["tab_2_title"]) # Add "tab2" to the tabs holder "tabs" 

        layout.addWidget(tab_holder)

sp_window = App()
sp_window.show()