import os
import sys

from PyQt5 import QtGui, QtWidgets, QtCore


class MyMainWindow(QtWidgets.QMainWindow):
    '''
    '''
    def __init__(self, parent=None):
        super(MyMainWindow, self).__init__(parent)

        self.setWindowTitle('My Tool')
        self.setGeometry(100, 300, 1000, 600)
        self.setMinimumSize(450,200)

        self.sp_widget = MainWidget()
        self.setCentralWidget(self.sp_widget)


class MainWidget(QtWidgets.QWidget):
    '''
    '''
    def __init__(self, parent = None):
        super(MainWidget, self).__init__(parent)
        self.build_ui()


    def build_ui(self):
        '''
        '''
        # Main widget
        self.main_layout = QtWidgets.QVBoxLayout(self)
        self.rename_btn = QtWidgets.QPushButton('Auto-Fix Conflicts')
        self.rename_btn.setFixedHeight(50)
        self.rename_btn.setStyleSheet('color: #224f33; background-color: #3cba6d; font-weight: bold; font-size: 18px;')
 
        ##
        # Build button layout
        self.main_layout.addWidget(self.rename_btn)

sp_window = MyMainWindow()
sp_window.show()