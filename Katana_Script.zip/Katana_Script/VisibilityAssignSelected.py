from PyQt5 import QtGui
from Katana import NodegraphAPI
from Katana import ScenegraphManager

def VisAssignSelectedObjects():
    CELtext = ""
    celCount = 0

    # get the selected nodes from the scenegraph
    scene = ScenegraphManager.getActiveScenegraph()
    paths = scene.getSelectedLocations()
    for i in range(len(paths)):
        CELtext = CELtext + " " +paths[i]
        celCount = celCount + 1

    visNode = NodegraphAPI.GetNode("VisibilityAssign")
    visNode.getParameter("CEL").setValue(CELtext,0)

    print "VisAssignSelectedObjects: %d objects hide." % celCount

# throw an error if nothing is selected
if len(items) == 0:
    print("Error, Need Selected Object")
else:
    VisAssignSelectedObjects()
